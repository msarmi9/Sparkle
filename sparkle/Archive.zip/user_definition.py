# https://developers.google.com/maps/documentation/javascript/get-api-key
apikey = "AIzaSyCqtkDaTJE3ah__vjzeCyXq8ss3o-ovpR0"
orig_coord = '37.7909,-122.3925'
dest_coord = '37.7765,-122.4506'
output_file = 'time.tsv'
bucket_name="msds694"
